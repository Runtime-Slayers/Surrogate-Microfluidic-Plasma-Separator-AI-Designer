

import React from 'react';
import { useState, useCallback } from 'react';
import { OptimizerControl } from './components/OptimizerControl';
import { ResultsDisplay } from './components/ResultsDisplay';
import { PerformanceCharts } from './components/PerformanceCharts';
import { GeminiAnalysis } from './components/GeminiAnalysis';
import { InteractiveSimulation } from './components/InteractiveSimulation';
import { runOptimization, mockSurrogateModel, testUnderVaryingConditions, generateParameterSweepData, generatePillarLayoutSweepData } from './services/optimizationService';
import { generateDesignRationale } from './services/geminiService';
import { OptimizationResult, TestConditionResult, ParameterSweepResult, PillarLayoutSweepResult } from './types';

const App: React.FC = () => {
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [optimizationProgress, setOptimizationProgress] = useState<number>(0);
  const [optimizationResult, setOptimizationResult] = useState<OptimizationResult | null>(null);
  const [testResults, setTestResults] = useState<TestConditionResult[]>([]);
  const [sweepResults, setSweepResults] = useState<ParameterSweepResult[]>([]);
  const [pillarLayoutSweepResults, setPillarLayoutSweepResults] = useState<PillarLayoutSweepResult[]>([]);
  
  const [isGeneratingAnalysis, setIsGeneratingAnalysis] = useState<boolean>(false);
  const [analysis, setAnalysis] = useState<string | null>(null);

  const handleStartOptimization = useCallback(async () => {
    setIsOptimizing(true);
    setOptimizationResult(null);
    setTestResults([]);
    setSweepResults([]);
    setPillarLayoutSweepResults([]);
    setAnalysis(null);
    setOptimizationProgress(0);

    try {
      const { bestDesignParams, predictedPerformance } = await runOptimization(1000, (progress) => {
        setOptimizationProgress(progress);
      });
      
      // Simulate validation with a higher complexity mock CFD run
      const validatedPerformance = mockSurrogateModel(bestDesignParams, 2.0);
      const finalResult = { bestDesignParams, predictedPerformance, validatedPerformance };
      setOptimizationResult(finalResult);
      
      const varyingConditionResults = testUnderVaryingConditions(bestDesignParams);
      setTestResults(varyingConditionResults);

      const sweepData = generateParameterSweepData(bestDesignParams);
      setSweepResults(sweepData);

      const pillarLayoutData = generatePillarLayoutSweepData(bestDesignParams);
      setPillarLayoutSweepResults(pillarLayoutData);

      // Trigger Gemini Analysis
      setIsGeneratingAnalysis(true);
      const rationale = await generateDesignRationale(bestDesignParams, validatedPerformance);
      setAnalysis(rationale);
      setIsGeneratingAnalysis(false);

    } catch (error) {
      console.error("Optimization failed:", error);
      // Here you could set an error state to show in the UI
    } finally {
      setIsOptimizing(false);
    }
  }, []);

  return (
    <div className="min-h-screen p-4 lg:p-8">
        <div 
            className="absolute top-0 left-0 w-full h-full bg-repeat opacity-[0.03]" 
            style={{backgroundImage: "url('https://www.toptal.com/designers/subtlepatterns/patterns/graph-paper.png')"}}>
        </div>
        <main className="container mx-auto max-w-screen-2xl relative z-10 space-y-8">
            <header className="text-center py-6">
                <h1 className="text-4xl lg:text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-sky-500 to-blue-700">
                    Microfluidic Plasma Separator AI Designer
                </h1>
                <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                    Leveraging AI to accelerate the design and optimization of next-generation biomedical devices.
                </p>
            </header>

            <section className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                 <div className="lg:col-span-2">
                    <OptimizerControl 
                        isOptimizing={isOptimizing} 
                        onStart={handleStartOptimization}
                        progress={optimizationProgress}
                    />
                </div>
                 <div className="lg:col-span-3 h-full">
                    <InteractiveSimulation 
                        initialDesign={optimizationResult}
                    />
                </div>
            </section>

            {optimizationResult && (
                <>
                    <section>
                       <ResultsDisplay result={optimizationResult} />
                    </section>
                    <section>
                        <GeminiAnalysis analysis={analysis} isLoading={isGeneratingAnalysis} />
                    </section>
                    <section>
                       <PerformanceCharts data={testResults} sweepData={sweepResults} pillarLayoutSweepData={pillarLayoutSweepResults} />
                    </section>
                </>
            )}

            <footer className="text-center text-gray-500 py-6 text-sm">
                <p>Powered by React, Tailwind CSS, and Gemini AI.</p>
                <p>This is a conceptual tool. Designs and performance metrics are simulated.</p>
            </footer>
        </main>
    </div>
  );
};

export default App;