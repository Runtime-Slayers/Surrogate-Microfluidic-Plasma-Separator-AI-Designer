
export interface DesignParameters {
  channel_width: number;
  channel_height: number;
  pillar_diameter: number;
  pillar_spacing_x: number;
  pillar_spacing_y: number;
  num_pillar_rows: number;
  num_pillar_cols: number;
  inlet_flow_rate: number;
  blood_hematocrit: number;
}

export interface PerformanceMetrics {
  plasma_purity: number;
  plasma_recovery: number;
  pressure_drop_kPa: number;
}

export interface OptimizationResult {
  bestDesignParams: DesignParameters;
  predictedPerformance: PerformanceMetrics;
  validatedPerformance: PerformanceMetrics;
}

export interface TestConditionResult extends PerformanceMetrics {
  flow_rate: number;
  hematocrit: number;
}

export interface ParameterSweepResult {
  pillar_diameter: number;
  pillar_spacing_x: number;
  plasma_purity: number;
}

export interface PillarLayoutSweepResult {
  num_pillar_rows: number;
  num_pillar_cols: number;
  plasma_purity: number;
  plasma_recovery: number;
}

export type OverlayType = 'none' | 'velocity' | 'shear';

export interface PhysicsMetrics {
  averageVelocity: number; // m/s
  reynoldsNumber: number;
  pecletNumber: number;
  maxWallShearStress: number; // Pa
}