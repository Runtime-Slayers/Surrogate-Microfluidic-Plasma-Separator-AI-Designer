import React from 'react';
import { Card } from './common/Card';
import { AIEnhanceIcon } from './common/Icons';

interface GeminiAnalysisProps {
  analysis: string | null;
  isLoading: boolean;
}

// A simple markdown parser
const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
    const lines = text.split('\n');
    const elements = lines.map((line, index) => {
        if (line.startsWith('### ')) return <h3 key={index} className="text-lg font-semibold mt-4 mb-2 text-sky-700">{line.substring(4)}</h3>;
        if (line.startsWith('## ')) return <h2 key={index} className="text-xl font-bold mt-4 mb-2 text-sky-600">{line.substring(3)}</h2>;
        if (line.startsWith('# ')) return <h1 key={index} className="text-2xl font-extrabold mt-4 mb-2 text-blue-700">{line.substring(2)}</h1>;
        if (line.startsWith('1. ') || line.startsWith('2. ') || line.startsWith('3. ')) {
            const boldedLine = line.substring(3).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            return <p key={index} className="mb-2 text-gray-700 ml-4"><span className="font-bold text-sky-600">{line.substring(0,3)}</span><span dangerouslySetInnerHTML={{ __html: boldedLine }}/></p>;
        }
        if (line.startsWith('- ')) return <li key={index} className="mb-1 ml-6 text-gray-700 list-disc">{line.substring(2)}</li>;
        
        const boldedLine = line.replace(/\*\*(.*?)\*\*/g, '<strong class="text-gray-800 font-semibold">$1</strong>');
        return <p key={index} className="mb-3 text-gray-700" dangerouslySetInnerHTML={{ __html: boldedLine }} />;
    });
    return <>{elements}</>;
};

export const GeminiAnalysis: React.FC<GeminiAnalysisProps> = ({ analysis, isLoading }) => {
  return (
    <Card title="AI-Powered Design Analysis" className='min-h-[200px]'>
      {isLoading && (
        <div className="flex flex-col items-center justify-center h-full text-gray-500">
          <AIEnhanceIcon className="w-10 h-10 animate-spin text-sky-500 mb-4" />
          <p>Generating insights with Gemini...</p>
        </div>
      )}
      {!isLoading && !analysis && (
        <div className="flex flex-col items-center justify-center h-full text-gray-500">
           <AIEnhanceIcon className="w-16 h-16 mx-auto mb-4 text-gray-400"/>
           <p>AI analysis of the optimized design will appear here.</p>
        </div>
      )}
      {!isLoading && analysis && (
        <div className="prose prose-p:text-gray-700 prose-strong:text-gray-900 max-w-none">
          <SimpleMarkdown text={analysis} />
        </div>
      )}
    </Card>
  );
};