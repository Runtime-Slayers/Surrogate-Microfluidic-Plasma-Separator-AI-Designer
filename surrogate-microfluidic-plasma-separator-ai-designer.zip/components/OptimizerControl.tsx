import React from 'react';
import { Card } from './common/Card';
import { designParameterBounds } from '../services/optimizationService';
import { LabFlaskIcon } from './common/Icons';

interface OptimizerControlProps {
  isOptimizing: boolean;
  onStart: () => void;
  progress: number;
}

const formatParamName = (name: string) => {
    return name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
};

export const OptimizerControl: React.FC<OptimizerControlProps> = ({ isOptimizing, onStart, progress }) => {
  return (
    <Card title="Design Optimizer" className="h-full flex flex-col">
        <div className="flex-grow">
            <p className="text-gray-600 mb-4">
                This tool uses a surrogate AI model to find the optimal geometric parameters for a microfluidic plasma separator. Click "Start Optimization" to begin the process.
            </p>
            <div className="bg-gray-100/50 rounded-md p-4 mb-4 border border-gray-300">
                <h3 className="font-semibold text-lg text-gray-700 mb-2">Design Parameter Space</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-2 text-sm">
                {Object.entries(designParameterBounds).map(([key, value]) => (
                    <div key={key}>
                        <span className="font-medium text-gray-500">{formatParamName(key)}: </span>
                        <span className="text-sky-600 font-medium">{value.min} - {value.max} {value.unit}</span>
                    </div>
                ))}
                </div>
            </div>
            {isOptimizing && (
                 <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                    <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: `${progress * 100}%` }}></div>
                </div>
            )}
        </div>
      
        <button
            onClick={onStart}
            disabled={isOptimizing}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-400 text-white font-bold py-3 px-4 rounded-lg transition duration-300 ease-in-out shadow-md disabled:cursor-not-allowed"
        >
            <LabFlaskIcon className="w-5 h-5"/>
            {isOptimizing ? `Optimizing... (${(progress * 100).toFixed(0)}%)` : 'Start Optimization'}
        </button>
    </Card>
  );
};