
import React, { useState, useEffect, useMemo } from 'react';
import { Card } from './common/Card';
import { DesignParameters, PerformanceMetrics, OptimizationResult, PhysicsMetrics, OverlayType } from '../types';
import { SettingsIcon, BellIcon, PatientIcon, HistoryIcon, CubeIcon, RestartIcon } from './common/Icons';
import { designParameterBounds, mockSurrogateModel } from '../services/optimizationService';
import { calculatePhysicsMetrics } from '../services/physicsService';
import { DeviceVisualizer } from './DeviceVisualizer';

// --- PROPS ---
interface InteractiveSimulationProps {
  initialDesign: OptimizationResult | null;
}

// --- SUB-COMPONENTS ---

const StandbyScreen: React.FC = () => (
  <Card title="Device Standby" className="h-full w-full flex flex-col items-center justify-center bg-gray-50/80">
    <CubeIcon className="w-24 h-24 text-gray-400 mb-4" />
    <h3 className="text-xl font-bold text-gray-500">Awaiting Optimized Design</h3>
    <p className="text-gray-400 mt-2">Please run the optimizer to begin simulation.</p>
  </Card>
);

const DigitalControlKnob: React.FC<{ label: string, unit: string, value: number, min: number, max: number, step: number, onValueChange: (value: number) => void }> = ({ label, unit, value, min, max, step, onValueChange }) => {
    const percentage = ((value - min) / (max - min)) * 100;
    
    return (
        <div className="text-center">
            <div className="relative inline-block w-28 h-28">
                <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                    <circle cx="50" cy="50" r="45" stroke="#d1d5db" strokeWidth="8" fill="none" pathLength="100" strokeDasharray="75 25" transform="rotate(135 50 50)" />
                    <circle cx="50" cy="50" r="45" stroke="#0ea5e9" strokeWidth="8" fill="none" pathLength="100" strokeDasharray={`${percentage * 0.75} ${100 - (percentage * 0.75)}`} transform="rotate(135 50 50)" className="transition-all duration-200 ease-out" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="font-mono font-bold text-2xl text-gray-800">{label === 'Hematocrit' ? (value * 100).toFixed(1) : value.toFixed(2)}</span>
                    <span className="text-xs text-gray-500">{unit}</span>
                </div>
            </div>
            <label className="block font-semibold text-gray-700 mt-2">{label}</label>
            <input 
                type="range" min={min} max={max} step={step} value={value} 
                onChange={(e) => onValueChange(parseFloat(e.target.value))} 
                className="w-full h-1 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-sky-500 mt-2" 
            />
        </div>
    );
};

const IntegerSlider: React.FC<{ label: string, value: number, min: number, max: number, onValueChange: (value: number) => void }> = ({ label, value, min, max, onValueChange }) => (
    <div className="px-2">
        <label className="flex justify-between font-semibold text-gray-700 text-sm">
            <span>{label}</span>
            <span className="font-mono text-blue-600">{value}</span>
        </label>
        <input 
            type="range" min={min} max={max} step={1} value={value} 
            onChange={(e) => onValueChange(parseInt(e.target.value, 10))} 
            className="w-full h-1 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-sky-500 mt-1" 
        />
    </div>
);

// --- MAIN COMPONENT ---
export const InteractiveSimulation: React.FC<InteractiveSimulationProps> = ({ initialDesign }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [baseDesign, setBaseDesign] = useState<DesignParameters | null>(initialDesign?.bestDesignParams ?? null);
  const [livePerformance, setLivePerformance] = useState<PerformanceMetrics | null>(initialDesign?.validatedPerformance ?? null);
  const [physicsMetrics, setPhysicsMetrics] = useState<PhysicsMetrics | null>(null);
  const [overlayType, setOverlayType] = useState<OverlayType>('none');
  
  const [flowRate, setFlowRate] = useState(initialDesign?.bestDesignParams?.inlet_flow_rate ?? designParameterBounds.inlet_flow_rate.min);
  const [hematocrit, setHematocrit] = useState(initialDesign?.bestDesignParams?.blood_hematocrit ?? designParameterBounds.blood_hematocrit.min);
  const [pillarRows, setPillarRows] = useState(initialDesign?.bestDesignParams?.num_pillar_rows ?? designParameterBounds.num_pillar_rows.min);
  const [pillarCols, setPillarCols] = useState(initialDesign?.bestDesignParams?.num_pillar_cols ?? designParameterBounds.num_pillar_cols.min);
  
  const [treatmentTime, setTreatmentTime] = useState(0);
  const [particleDensity, setParticleDensity] = useState(0.5);
  const [resetKey, setResetKey] = useState(0);
  
  const handleResetSimulation = () => setResetKey(prev => prev + 1);

  useEffect(() => {
    if (initialDesign) {
      const designParams = initialDesign.bestDesignParams;
      setBaseDesign(designParams);
      setLivePerformance(initialDesign.validatedPerformance);
      setPhysicsMetrics(calculatePhysicsMetrics(designParams));
      setFlowRate(designParams.inlet_flow_rate);
      setHematocrit(designParams.blood_hematocrit);
      setPillarRows(designParams.num_pillar_rows);
      setPillarCols(designParams.num_pillar_cols);
      setIsRunning(false);
      setTreatmentTime(0);
      setOverlayType('none');
      handleResetSimulation();
    }
  }, [initialDesign]);
  
  const currentSimDesign = useMemo<DesignParameters | null>(() => {
    if (!baseDesign) return null;
    return {
      ...baseDesign,
      inlet_flow_rate: flowRate,
      blood_hematocrit: hematocrit,
      num_pillar_rows: pillarRows,
      num_pillar_cols: pillarCols,
    };
  }, [baseDesign, flowRate, hematocrit, pillarRows, pillarCols]);

  useEffect(() => {
    if (!currentSimDesign) return;
    setLivePerformance(mockSurrogateModel(currentSimDesign, 1.5));
    setPhysicsMetrics(calculatePhysicsMetrics(currentSimDesign));
  }, [currentSimDesign]);
  
  useEffect(() => {
    let timer: number;
    if (isRunning) {
        timer = window.setInterval(() => setTreatmentTime(prev => prev + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [isRunning])

  const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
      const secs = (seconds % 60).toString().padStart(2, '0');
      return `${mins}:${secs}`;
  }

  if (!baseDesign || !livePerformance || !physicsMetrics || !currentSimDesign) { return <StandbyScreen />; }
  
  const keyframes = `@keyframes pump-rotation { from { transform: rotate(0deg); } to { transform: rotate(360deg); } } @keyframes flow-animation-red { from { background-position: 0 0; } to { background-position: 50px 0; } } @keyframes flow-animation-yellow { from { background-position: 0 0; } to { background-position: -50px 0; } }`;
  const pumpAnimationDuration = Math.max(0.2, 3 / flowRate);
  const maxParticles = Math.floor(50 + particleDensity * 350);

  return (
    <Card className="h-full flex flex-col" title="Live Device Control & Simulation">
      <style>{keyframes}</style>
      <div className="flex-grow w-full bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg p-4 grid grid-cols-5 gap-4 shadow-2xl border-4 border-gray-400">
        
        <div className="col-span-3 bg-white rounded-md p-1.5 shadow-inner flex flex-col text-gray-800">
            <div className='bg-gray-50 rounded-sm flex-grow p-4 flex flex-col'>
                <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                    <div className="flex items-center gap-2"> <PatientIcon className="w-6 h-6 text-sky-500" /> <div> <div className="font-bold">PATIENT: 78B-451</div> <div className="text-xs text-gray-500">PROTOCOL: STANDARD PLASMA SEPARATION</div> </div> </div>
                    <div className="flex items-center gap-4"> <BellIcon className="w-6 h-6 text-gray-400 hover:text-yellow-500 cursor-pointer"/> <SettingsIcon className="w-6 h-6 text-gray-400 hover:text-sky-500 cursor-pointer"/> </div>
                </div>

                <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                    <div className='space-y-3'>
                        <h3 className="text-lg font-bold text-blue-600 border-b border-blue-600/20 pb-1">REAL-TIME PERFORMANCE</h3>
                        <div className="flex justify-between text-xl"><span className="text-gray-500">Plasma Purity:</span> <span className="font-mono font-bold text-green-600">{(livePerformance.plasma_purity * 100).toFixed(1)}%</span></div>
                        <div className="flex justify-between text-xl"><span className="text-gray-500">Plasma Recovery:</span> <span className="font-mono font-bold text-green-600">{(livePerformance.plasma_recovery * 100).toFixed(1)}%</span></div>
                        <div className="flex justify-between text-xl"><span className="text-gray-500">Pressure Drop:</span> <span className="font-mono font-bold text-green-600">{livePerformance.pressure_drop_kPa.toFixed(2)} kPa</span></div>
                        <div className="flex justify-between text-xl"><span className="text-gray-500">Treatment Time:</span> <span className="font-mono font-bold">{formatTime(treatmentTime)}</span></div>
                         <button onClick={handleResetSimulation} className="w-full flex items-center justify-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out !mt-6 border border-gray-300"> <RestartIcon className="w-5 h-5"/> Reset Simulation </button>
                    </div>
                     <div className='flex flex-col'>
                        <div>
                            <h3 className="text-lg text-center font-bold text-blue-600 border-b border-blue-600/20 pb-1">OPERATIONAL CONTROLS</h3>
                            <div className="flex justify-around pt-4">
                                <DigitalControlKnob label="Flow Rate" unit="mL/hr" value={flowRate} min={designParameterBounds.inlet_flow_rate.min} max={designParameterBounds.inlet_flow_rate.max} step={0.01} onValueChange={setFlowRate} />
                                <DigitalControlKnob label="Hematocrit" unit="%" value={hematocrit} min={0.05} max={0.95} step={0.001} onValueChange={setHematocrit} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <h3 className="text-lg text-center font-bold text-blue-600 border-b border-blue-600/20 pb-1">STRUCTURAL CONTROLS</h3>
                            <IntegerSlider label="Pillar Rows" value={pillarRows} min={designParameterBounds.num_pillar_rows.min} max={designParameterBounds.num_pillar_rows.max} onValueChange={setPillarRows} />
                            <IntegerSlider label="Pillar Columns" value={pillarCols} min={designParameterBounds.num_pillar_cols.min} max={designParameterBounds.num_pillar_cols.max} onValueChange={setPillarCols} />
                        </div>
                        <div className='px-2 mt-auto'>
                           <h3 className="text-lg text-center font-bold text-blue-600 border-b border-blue-600/20 pb-1 mb-2 mt-4">PHYSICS INSPECTOR</h3>
                           <div className='text-sm space-y-1 bg-gray-100 p-2 rounded-md border border-gray-200'>
                                <div className="flex justify-between"><span className="text-gray-500">Avg. Velocity:</span> <span className="font-mono font-bold">{physicsMetrics.averageVelocity.toExponential(2)} m/s</span></div>
                                <div className="flex justify-between"><span className="text-gray-500">Reynolds No.:</span> <span className="font-mono font-bold">{physicsMetrics.reynoldsNumber.toFixed(3)}</span></div>
                                <div className="flex justify-between"><span className="text-gray-500">Péclet No.:</span> <span className="font-mono font-bold">{physicsMetrics.pecletNumber.toExponential(2)}</span></div>
                                <div className="flex justify-between"><span className="text-gray-500">Max Shear Stress:</span> <span className={`font-mono font-bold ${physicsMetrics.maxWallShearStress > 20 ? 'text-red-600' : 'text-amber-600'}`}>{physicsMetrics.maxWallShearStress.toFixed(2)} Pa</span></div>
                           </div>
                           <div className='grid grid-cols-2 gap-2 mt-2'>
                                <button onClick={() => setOverlayType(prev => prev === 'velocity' ? 'none' : 'velocity')} className={`text-xs p-1 rounded transition-colors ${overlayType === 'velocity' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}>Velocity Field</button>
                                <button onClick={() => setOverlayType(prev => prev === 'shear' ? 'none' : 'shear')} className={`text-xs p-1 rounded transition-colors ${overlayType === 'shear' ? 'bg-red-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}>Shear Stress</button>
                           </div>
                        </div>
                     </div>
                </div>

                <div className="flex justify-between items-center border-t border-gray-200 pt-3">
                    <div className={`font-bold text-lg uppercase p-2 rounded-md ${isRunning ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{isRunning ? 'TREATMENT IN PROGRESS' : 'SYSTEM PAUSED'}</div>
                    <div className="flex gap-2">
                        <button className="flex items-center gap-2 font-bold p-2 rounded-md bg-gray-200 hover:bg-gray-300 border border-gray-300"><HistoryIcon className="w-5 h-5"/>History</button>
                        <button onClick={() => setIsRunning(!isRunning)} className={`flex items-center gap-2 font-bold text-xl text-white px-6 py-3 rounded-md transition-all ${isRunning ? 'bg-yellow-500 hover:bg-yellow-400' : 'bg-green-500 hover:bg-green-400'}`}> {isRunning ? 'PAUSE' : 'START'} </button>
                    </div>
                </div>
            </div>
        </div>

        <div className="col-span-2 flex flex-col justify-between space-y-4">
             <div>
                <h3 className="text-center font-bold text-gray-600 uppercase tracking-wider text-sm">System Status</h3>
                <div className="flex justify-around items-center bg-gray-500/50 p-2 rounded-lg mt-1 border border-gray-400">
                    <div className="flex flex-col items-center"><div className={`w-5 h-5 rounded-full border-2 border-black ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-green-800'}`}></div><span className="text-xs text-white font-bold">RUN</span></div>
                    <div className="flex flex-col items-center"><div className={`w-5 h-5 rounded-full border-2 border-black ${!isRunning && baseDesign ? 'bg-yellow-500 animate-pulse' : 'bg-yellow-800'}`}></div><span className="text-xs text-white font-bold">IDLE</span></div>
                    <div className="flex flex-col items-center"><div className="w-5 h-5 rounded-full bg-red-800 border-2 border-black"></div><span className="text-xs text-white font-bold">ALARM</span></div>
                </div>
            </div>

            <div className="bg-gray-800/20 p-2 rounded-lg border border-gray-400 flex-grow relative min-h-[250px]">
                 <DeviceVisualizer params={currentSimDesign} flowRate={flowRate} hematocrit={hematocrit} isRunning={isRunning} maxParticles={maxParticles} resetKey={resetKey} overlayType={overlayType} />
            </div>
            
            <div className="bg-gray-500/50 p-3 rounded-lg border border-gray-400">
                <h3 className="text-center font-bold text-gray-700 uppercase tracking-wider text-sm mb-2">Fluidics</h3>
                <div className="grid grid-cols-3 gap-2 items-start">
                    <div className="flex flex-col items-center space-y-1">
                        <div className="w-full h-4 rounded-full border-2 border-red-800 bg-red-600/50 relative overflow-hidden">
                           <div className={`absolute top-0 left-0 w-full h-full bg-[linear-gradient(45deg,rgba(255,255,255,0.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.2)_50%,rgba(255,255,255,0.2)_75%,transparent_75%,transparent)] bg-[length:50px_50px]`} style={{ animation: isRunning ? 'flow-animation-red 2s infinite linear' : 'none'}}></div>
                        </div>
                        <span className="text-xs text-gray-800 font-bold">BLOOD IN</span>
                         <div className="text-center text-[10px] leading-tight text-gray-600 font-semibold">
                            <div>{(hematocrit * 100).toFixed(0)}% RBC</div>
                            <div>{(100 - hematocrit * 100).toFixed(0)}% Plasma</div>
                        </div>
                    </div>
                    <div className="relative w-16 h-16 mx-auto mt-1">
                        <div className="w-full h-full rounded-full bg-gray-500 border-4 border-gray-600"></div>
                        <div 
                            className="absolute inset-2 rounded-full bg-gray-800 flex items-center justify-center" 
                            style={{ animationName: 'pump-rotation', animationTimingFunction: 'linear', animationIterationCount: 'infinite', animationDuration: `${pumpAnimationDuration.toFixed(2)}s`, animationPlayState: isRunning ? 'running' : 'paused' }}>
                            <div className="w-2 h-2 bg-gray-400 rounded-full absolute top-1"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full absolute bottom-1"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full absolute left-1"></div>
                        </div>
                    </div>
                    <div className="flex flex-col items-center space-y-1">
                        <div className="w-full h-4 rounded-full border-2 border-yellow-600 bg-yellow-400/50 relative overflow-hidden">
                             <div className={`absolute top-0 left-0 w-full h-full bg-[linear-gradient(45deg,rgba(255,255,255,0.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.2)_50%,rgba(255,255,255,0.2)_75%,transparent_75%,transparent)] bg-[length:50px_50px]`} style={{ animation: isRunning ? 'flow-animation-yellow 2s infinite linear' : 'none'}}></div>
                        </div>
                        <span className="text-xs text-gray-800 font-bold">PLASMA OUT</span>
                         <div className="text-center text-[10px] leading-tight text-gray-600 font-semibold">
                            <div>{(livePerformance.plasma_purity * 100).toFixed(1)}% Pure</div>
                            <div>&nbsp;</div>
                        </div>
                    </div>
                </div>
            </div>
            <button className='w-16 h-16 rounded-full bg-red-600 border-4 border-red-800 shadow-lg text-white font-bold text-xs self-center flex items-center justify-center text-center hover:bg-red-500 active:bg-red-700'>EMERG. STOP</button>
        </div>
      </div>
    </Card>
  );
};