import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
}

export const Card: React.FC<CardProps> = ({ children, className = '', title }) => {
  return (
    <div className={`bg-white/70 backdrop-blur-md border border-gray-200/80 rounded-lg shadow-lg p-6 ${className}`}>
      {title && <h2 className="text-xl font-bold text-blue-600 mb-4">{title}</h2>}
      {children}
    </div>
  );
};