import React from 'react';
import { OptimizationResult, PerformanceMetrics } from '../types';
import { Card } from './common/Card';
import { SlidersIcon, ChartIcon, BellIcon, HistoryIcon, PowerIcon } from './common/Icons';

interface ResultsDisplayProps {
  result: OptimizationResult | null;
}

const ParameterItem: React.FC<{ label: string; value: string; unit?: string; }> = ({ label, value, unit }) => (
  <div className="flex justify-between items-baseline py-1.5 border-t border-gray-200/70">
    <span className="text-gray-600 text-sm">{label}</span>
    <span className="font-mono font-semibold text-sky-600">{value} <span className="text-xs text-gray-400">{unit}</span></span>
  </div>
);

const PerformanceMetric: React.FC<{ icon: React.ReactNode; label: string; value: string; color: string; delta?: number; }> = ({ icon, label, value, color, delta }) => (
  <div className="flex items-start space-x-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
    <div className={`p-2 rounded-md ${color.replace('text', 'bg').replace('-400', '-100')}`}>{icon}</div>
    <div>
      <p className="text-gray-500 text-sm font-medium">{label}</p>
      <div className="flex items-baseline space-x-2">
        <p className={`text-2xl font-bold font-mono ${color}`}>{value}</p>
        {delta !== undefined && (
          <span className={`text-xs font-mono font-semibold px-1.5 py-0.5 rounded-full ${delta >= 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
            {delta >= 0 ? '+' : ''}{(delta * 100).toFixed(1)}%
          </span>
        )}
      </div>
    </div>
  </div>
);

const PerformanceCard: React.FC<{ title: string; performance: PerformanceMetrics; predicted?: PerformanceMetrics }> = ({ title, performance, predicted }) => {
  const purityDelta = predicted ? (performance.plasma_purity - predicted.plasma_purity) / predicted.plasma_purity : undefined;
  const recoveryDelta = predicted ? (performance.plasma_recovery - predicted.plasma_recovery) / predicted.plasma_recovery : undefined;
  const pressureDelta = predicted ? (performance.pressure_drop_kPa - predicted.pressure_drop_kPa) / predicted.pressure_drop_kPa : undefined;

  return (
    <Card title={title}>
      <div className="space-y-4">
        <PerformanceMetric 
          icon={<BellIcon className="w-6 h-6 text-green-500" />} 
          label="Plasma Purity" 
          value={performance.plasma_purity.toFixed(4)}
          color="text-green-500"
          delta={purityDelta}
        />
        <PerformanceMetric 
          icon={<HistoryIcon className="w-6 h-6 text-green-500" />} 
          label="Plasma Recovery" 
          value={performance.plasma_recovery.toFixed(4)}
          color="text-green-500"
          delta={recoveryDelta}
        />
        <PerformanceMetric 
          icon={<PowerIcon className="w-6 h-6 text-amber-500" />} 
          label="Pressure Drop (kPa)" 
          value={performance.pressure_drop_kPa.toFixed(4)}
          color="text-amber-500"
          delta={pressureDelta}
        />
      </div>
    </Card>
  )
};


export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result }) => {
  if (!result) {
    return null;
  }

  const { bestDesignParams, predictedPerformance, validatedPerformance } = result;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card title="Optimized Design">
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-2"><SlidersIcon className="w-4 h-4" />Geometric Parameters</h3>
            <ParameterItem label="Channel Width" value={bestDesignParams.channel_width.toFixed(2)} unit="µm" />
            <ParameterItem label="Channel Height" value={bestDesignParams.channel_height.toFixed(2)} unit="µm" />
            <ParameterItem label="Pillar Diameter" value={bestDesignParams.pillar_diameter.toFixed(2)} unit="µm" />
            <ParameterItem label="Pillar Spacing X" value={bestDesignParams.pillar_spacing_x.toFixed(2)} unit="µm" />
            <ParameterItem label="Pillar Spacing Y" value={bestDesignParams.pillar_spacing_y.toFixed(2)} unit="µm" />
            <ParameterItem label="Pillar Rows" value={bestDesignParams.num_pillar_rows.toString()} />
            <ParameterItem label="Pillar Columns" value={bestDesignParams.num_pillar_cols.toString()} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2 mt-4 flex items-center gap-2"><ChartIcon className="w-4 h-4"/>Flow Conditions</h3>
            <ParameterItem label="Flow Rate" value={bestDesignParams.inlet_flow_rate.toFixed(2)} unit="mL/hr"/>
            <ParameterItem label="Hematocrit" value={(bestDesignParams.blood_hematocrit * 100).toFixed(1)} unit="%"/>
          </div>
        </div>
      </Card>
      
      <PerformanceCard title="AI Predicted Performance" performance={predictedPerformance} />
      <PerformanceCard title="Validated Performance" performance={validatedPerformance} predicted={predictedPerformance}/>
    </div>
  );
};