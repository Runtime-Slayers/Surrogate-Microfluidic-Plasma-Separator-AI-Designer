import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { DesignParameters, OverlayType } from '../types';

// --- TYPES & INTERFACES ---
type Particle = { id: number; x: number; y: number; vx: number; vy: number; type: 'rbc' | 'plasma'; };
type Pillar = { x: number; y: number; radius: number; };

// --- PROPS ---
interface DeviceVisualizerProps {
  params: DesignParameters | null;
  flowRate: number;
  hematocrit: number;
  isRunning: boolean;
  maxParticles: number;
  resetKey: number;
  overlayType: OverlayType;
}

// --- SUB-COMPONENTS ---
const ChannelWalls: React.FC = () => (
  <div className="absolute w-full h-full" style={{ transform: 'translateZ(1px)' }}>
    {/* Inlet */}
    <div className="wall top" style={{ top: '45%', left: '5%', width: '10%', height: '2px' }} />
    <div className="wall bottom" style={{ top: '55%', left: '5%', width: '10%', height: '2px' }} />
    {/* Flares */}
    <div className="wall" style={{ top: '27.5%', left: '15%', width: '2px', height: '35%', transform: 'rotate(45deg)' }} />
    <div className="wall" style={{ bottom: '27.5%', left: '15%', width: '2px', height: '35%', transform: 'rotate(-45deg)' }} />
    {/* Main Chamber */}
    <div className="wall top" style={{ top: '10%', left: '15%', width: '70%', height: '2px' }} />
    <div className="wall bottom" style={{ top: '90%', left: '15%', width: '70%', height: '2px' }} />
    {/* Splitter */}
    <div className="splitter" />
    {/* Outlets */}
    <div className="wall top" style={{ top: '10%', left: '85%', width: '10%', height: '2px' }} />
    <div className="wall bottom" style={{ top: '90%', left: '85%', width: '10%', height: '2px' }} />
    <div className="wall top" style={{ top: 'calc(50% - 2px)', left: '90%', width: '5%', height: '2px' }} />
    <div className="wall bottom" style={{ top: 'calc(50% + 2px)', left: '90%', width: '5%', height: '2px' }} />
  </div>
);

const SchematicOverlay: React.FC = () => (
  <div className="absolute inset-0 pointer-events-none text-blue-900/80 text-xs font-mono uppercase z-20">
    <div style={{ position: 'absolute', top: '58%', left: '5%' }}>Inlet Port</div>
    <div style={{ position: 'absolute', top: '52%', left: '10%', width: '5%', height: '1px', background: 'currentColor' }} />

    <div style={{ position: 'absolute', top: '5%', left: '50%', transform: 'translateX(-50%)' }}>Separation Chamber</div>
    <div className="absolute left-[20%] w-[60%] h-px bg-current opacity-30" style={{ top: '8%' }} />


    <div style={{ position: 'absolute', top: '58%', right: '8%' }}>Flow Splitter</div>
    <div style={{ position: 'absolute', top: '52%', right: '15%', width: '4%', height: '1px', background: 'currentColor' }} />
    
    <div style={{ position: 'absolute', top: '22%', right: '1%' }}>Plasma Outlet</div>
    <div style={{ position: 'absolute', top: '30%', right: '6%', width: '4%', height: '1px', background: 'currentColor' }} />

    <div style={{ position: 'absolute', top: '75%', right: '2%' }}>RBC Outlet</div>
    <div style={{ position: 'absolute', top: '72%', right: '6%', width: '4%', height: '1px', background: 'currentColor' }} />
  </div>
);

const PhysicsOverlay: React.FC<{ overlayType: OverlayType; width: number; height: number; }> = React.memo(({ overlayType, width, height }) => {
  if (overlayType === 'none') return null;

  const resolution = 20; // grid points
  const channelTop = height * 0.1;
  const channelHeight = height * 0.8;
  const points = [];

  for (let i = 0; i < resolution; i++) {
    const y_norm = (i + 0.5) / resolution; // normalized y-pos in channel (0 to 1)
    
    let color;
    if (overlayType === 'velocity') {
      // Parabolic profile: v = Vmax * (1 - (y/h)^2)
      // Color goes from blue (0) to yellow/red (1)
      const velocityFactor = 1 - Math.pow((y_norm - 0.5) * 2, 2);
      const hue = 240 * (1 - velocityFactor); // 240 (blue) -> 0 (red)
      color = `hsl(${hue}, 90%, 50%)`;
    } else { // shear
      // Shear profile: τ is max at walls, 0 in center
      // Color goes from blue (0) to red (1)
      const shearFactor = Math.abs((y_norm - 0.5) * 2);
      const hue = 240 * (1 - shearFactor); // 240 (blue) -> 0 (red)
      color = `hsl(${hue}, 90%, 50%)`;
    }
    
    points.push(
      <div
        key={i}
        className="absolute"
        style={{
          left: '15%',
          width: '70%',
          top: `${channelTop + y_norm * channelHeight}px`,
          height: `${channelHeight / resolution}px`,
          backgroundColor: color,
          transform: 'translateZ(-2px)', // Behind pillars
        }}
      />
    );
  }

  return <div className="absolute inset-0 opacity-40">{points}</div>;
});


// --- MAIN VISUALIZER COMPONENT ---
export const DeviceVisualizer: React.FC<DeviceVisualizerProps> = ({ params, flowRate, hematocrit, isRunning, maxParticles, resetKey, overlayType }) => {
  const [rotation, setRotation] = useState({ x: -25, y: -35 });
  const [isDragging, setIsDragging] = useState(false);
  const lastMousePos = useRef({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animationFrameId = useRef<number | null>(null);
  const [particleElements, setParticleElements] = useState<JSX.Element[]>([]);

  useEffect(() => {
    particlesRef.current = [];
  }, [resetKey]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - lastMousePos.current.x;
    const dy = e.clientY - lastMousePos.current.y;
    setRotation(prev => ({
      x: Math.max(-80, Math.min(80, prev.x - dy * 0.5)),
      y: prev.y + dx * 0.5
    }));
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => setIsDragging(false);

  const pillarData = useMemo<Pillar[]>(() => {
    if (!containerRef.current || !params) return [];
    const W = containerRef.current.clientWidth;
    const H = containerRef.current.clientHeight;

    if (W === 0 || H === 0) return [];

    const channelTopY = H * 0.1;
    const channelBottomY = H * 0.9;
    const pillarSectionStartX = W * 0.15;
    const pillarSectionEndX = W * 0.85;

    const { num_pillar_rows, num_pillar_cols } = params;
    
    const pillar_section_width = pillarSectionEndX - pillarSectionStartX;
    const pillar_section_height = channelBottomY - channelTopY;
    
    const p_spacing_x_vis = num_pillar_cols > 1 ? pillar_section_width / (num_pillar_cols - 1) : pillar_section_width;
    const p_spacing_y_vis = num_pillar_rows > 1 ? pillar_section_height / (num_pillar_rows - 1) : pillar_section_height;

    const conceptual_occlusion_ratio = params.pillar_diameter / params.pillar_spacing_x;
    const p_radius = (p_spacing_x_vis * conceptual_occlusion_ratio) / 2;
    
    const capped_p_radius = Math.min(p_radius, p_spacing_x_vis / 2.1, p_spacing_y_vis / 2.1);

    const pillars: Pillar[] = [];
    for (let row = 0; row < num_pillar_rows; row++) {
      const isStaggered = row % 2 !== 0;
      const xOffset = isStaggered ? p_spacing_x_vis / 2 : 0;
      const colsInThisRow = isStaggered ? num_pillar_cols - 1 : num_pillar_cols;

      if(colsInThisRow <= 0) continue;

      for (let col = 0; col < colsInThisRow; col++) {
        const x = pillarSectionStartX + col * p_spacing_x_vis + xOffset;
        const y = channelTopY + row * p_spacing_y_vis;
        pillars.push({ x, y, radius: capped_p_radius });
      }
    }
    return pillars;
  }, [params, containerRef.current?.clientWidth, containerRef.current?.clientHeight]);

  const runAnimation = useCallback(() => {
    if (!containerRef.current || !params) return;
    const W = containerRef.current.clientWidth;
    const H = containerRef.current.clientHeight;

    // Channel Geometry
    const mainChannelTopY = H * 0.1;
    const mainChannelBottomY = H * 0.9;
    const inletYCenter = H / 2;
    const inletHeight = H * 0.1;
    const pillarSectionStartX = W * 0.15;
    const pillarSectionEndX = W * 0.85;
    const splitterX = W * 0.90;
    const splitterY = H * 0.5;

    // --- Physics Constants ---
    const BROWNIAN_PLASMA = 0.2;
    const BROWNIAN_RBC = 0.03;
    const WALL_DAMPING = -0.3;
    const BASE_DLD_SHIFT_FORCE = 0.25;
    const PARTICLE_DAMPING = 0.98;
    const SHEAR_INDUCED_LIFT = 0.1;

    if (isRunning && particlesRef.current.length < maxParticles) {
      const isRBC = Math.random() < hematocrit;
      particlesRef.current.push({
        id: Math.random(),
        x: W * 0.05,
        y: inletYCenter + (Math.random() - 0.5) * (inletHeight * 0.8),
        vx: 0, vy: 0,
        type: isRBC ? 'rbc' : 'plasma'
      });
    }

    particlesRef.current = particlesRef.current.filter(p => p.x < W + 20);

    for (const p of particlesRef.current) {
        const p_radius = p.type === 'rbc' ? 3.5 : 2.0;

        // 1. Parabolic Flow Profile
        const channelHeight = (p.x < pillarSectionStartX) ? inletHeight : mainChannelBottomY - mainChannelTopY;
        const channelCenterY = (p.x < pillarSectionStartX) ? inletYCenter : H/2;
        const distFromCenter = Math.abs(p.y - channelCenterY);
        const flowFactor = 1 - (distFromCenter / (channelHeight / 2)) ** 2;
        let base_vx = (flowRate * 0.75) * Math.max(0.1, flowFactor);
        
        // 2. Brownian Motion & Damping
        p.vx += (Math.random() - 0.5) * (p.type === 'rbc' ? BROWNIAN_RBC : BROWNIAN_PLASMA);
        p.vy += (Math.random() - 0.5) * (p.type === 'rbc' ? BROWNIAN_RBC : BROWNIAN_PLASMA);
        p.vx = (p.vx + base_vx) / 2;
        
        // 3. Shear-Induced Lift (Margination)
        if (p.type === 'rbc' && p.x > pillarSectionStartX) {
            const distFromTop = p.y - mainChannelTopY;
            const distFromBottom = mainChannelBottomY - p.y;
            const currentChannelHeight = mainChannelBottomY - mainChannelTopY;

            if (distFromTop < currentChannelHeight * 0.2) {
                p.vy += SHEAR_INDUCED_LIFT * (1 - distFromTop / (currentChannelHeight * 0.2));
            }
            if (distFromBottom < currentChannelHeight * 0.2) {
                p.vy -= SHEAR_INDUCED_LIFT * (1 - distFromBottom / (currentChannelHeight * 0.2));
            }
        }

        // 4. Pillar Interaction & DLD Shift
        if (p.x > pillarSectionStartX && p.x < pillarSectionEndX) {
            for (const pillar of pillarData) {
                const dx = p.x - pillar.x;
                const dy = p.y - pillar.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const minDist = p_radius + pillar.radius;

                if (dist < minDist) {
                    const overlap = minDist - dist;
                    const normalX = dx / dist;
                    const normalY = dy / dist;
                    p.vx += normalX * overlap * 0.5;
                    p.vy += normalY * overlap * 0.5;
                    
                    if (p.type === 'rbc') {
                        const shiftForceFactor = 1.0 + Math.min(Math.abs(p.vx) * 0.2, 1.0);
                        p.vy += BASE_DLD_SHIFT_FORCE * shiftForceFactor;
                    }
                }
            }
        }
        
        // 5. Wall Interaction based on position
        let topY, bottomY;
        if (p.x < pillarSectionStartX) { // Inlet
            topY = inletYCenter - inletHeight / 2;
            bottomY = inletYCenter + inletHeight / 2;
        } else if (p.x > splitterX) { // Outlets
             if (p.y > splitterY) { // Bottom (RBC) outlet
                topY = splitterY + 2; bottomY = mainChannelBottomY;
            } else { // Top (plasma) outlet
                topY = mainChannelTopY; bottomY = splitterY - 2;
            }
        } else { // Main chamber
            topY = mainChannelTopY; bottomY = mainChannelBottomY;
        }

        if (p.y - p_radius < topY) { p.y = topY + p_radius; p.vy *= WALL_DAMPING; }
        if (p.y + p_radius > bottomY) { p.y = bottomY - p_radius; p.vy *= WALL_DAMPING; }

        // 6. Update position & apply damping
        p.x += p.vx; p.y += p.vy;
        p.vx *= PARTICLE_DAMPING; p.vy *= PARTICLE_DAMPING;
    }

    setParticleElements(particlesRef.current.map(p => 
        <div key={p.id} className={p.type === 'rbc' ? 'rbc-particle' : 'plasma-particle'} style={{ transform: `translate3d(${p.x}px, ${p.y}px, 2px)` }} />
    ));

    animationFrameId.current = requestAnimationFrame(runAnimation);
  }, [isRunning, flowRate, hematocrit, pillarData, maxParticles, params]);

  useEffect(() => {
    particlesRef.current = [];
    if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
    animationFrameId.current = requestAnimationFrame(runAnimation);
    return () => { if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current); };
  }, [runAnimation]);

  const pillarElements = useMemo(() => pillarData.map((p, i) => (
      <div key={i} className="pillar" style={{ width: `${p.radius * 2}px`, height: `${p.radius * 2}px`, transform: `translate3d(${p.x - p.radius}px, ${p.y - p.radius}px, 0px)` }}></div>
  )), [pillarData]);

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onMouseLeave={handleMouseUp}
      className="w-full h-full bg-gray-200 rounded-md overflow-hidden relative border-2 border-gray-400 shadow-inner shadow-black/20 cursor-grab active:cursor-grabbing"
      style={{ perspective: '1200px' }}
    >
      <style>{`
        .chip-base { background: #e5e7eb; box-shadow: inset 0 0 15px rgba(0,0,0,0.2); transform: translateZ(-3px); }
        .chip-top { background: rgba(255, 255, 255, 0.3); border: 1px solid rgba(209, 213, 219, 0.7); backdrop-filter: blur(2px); transform: translateZ(5px); box-shadow: inset 0 1px 2px rgba(255,255,255,0.5), 0 0 15px rgba(209, 213, 219, 0.5); }
        .pillar { position: absolute; border-radius: 50%; background-color: #a0aec0; background-image: linear-gradient(to right, rgba(255,255,255,0.3), rgba(255,255,255,0.1) 30%, transparent 50%); box-shadow: 1px 1px 3px rgba(0,0,0,0.3), inset 0 0 2px rgba(0,0,0,0.2); }
        .rbc-particle { position: absolute; width: 7px; height: 7px; background: #dc2626; border-radius: 50%; box-shadow: 0 0 3px #f87171; }
        .plasma-particle { position: absolute; width: 4px; height: 4px; background: #fde047; border-radius: 50%; opacity: 0.8; box-shadow: 0 0 4px #facc15; }
        .inlet-port, .outlet-port { position: absolute; width: 24px; height: 24px; background-image: radial-gradient(circle at 70% 30%, #e5e7eb, #9ca3af); border-radius: 50%; border: 2px solid #4b5563; box-shadow: inset 0 0 5px rgba(0,0,0,0.5), 0 0 3px rgba(255,255,255,0.2); }
        .inlet-port { top: 50%; left: 5%; margin-top: -12px; margin-left: -12px; }
        .outlet-port.plasma { top: 30%; right: 5%; margin-top: -12px; margin-right: -12px; }
        .outlet-port.rbc { top: 70%; right: 5%; margin-top: -12px; margin-right: -12px; }
        .chip-channel-floor { position: absolute; top: 10%; left: 0; width: 100%; height: 80%; background: #1e293b; box-shadow: inset 0 0 8px rgba(0,0,0,0.6); transform: translateZ(-2.5px); }
        .wall { position: absolute; background: rgba(14, 165, 233, 0.2); box-shadow: 0 0 5px rgba(14, 165, 233, 0.3); border-radius: 1px; }
        .splitter { position: absolute; top: 50%; left: 85%; width: 5%; height: 4px; margin-top: -2px; background: rgba(14, 165, 233, 0.2); box-shadow: 0 0 5px rgba(14, 165, 233, 0.3); clip-path: polygon(0 50%, 100% 0, 100% 100%); }
      `}</style>
      <SchematicOverlay />
      <div className="absolute top-1 left-2 text-blue-900 text-xs font-mono uppercase bg-white/50 px-1 rounded z-30">3D Chip View [Draggable]</div>
      <div className="w-full h-full" style={{ transformStyle: 'preserve-3d', transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
        <div className="absolute w-full h-full chip-base"></div>
        <div className="absolute w-full h-full chip-channel-floor">
          {containerRef.current && <PhysicsOverlay overlayType={overlayType} width={containerRef.current.clientWidth} height={containerRef.current.clientHeight}/>}
        </div>
        <div className="absolute w-full h-full"> {pillarElements} {particleElements} </div>
        <div className="absolute w-full h-full chip-top"> <ChannelWalls /> <div className="inlet-port"></div> <div className="outlet-port plasma"></div> <div className="outlet-port rbc"></div> </div>
      </div>
    </div>
  );
};