


import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, Cell, ZAxis } from 'recharts';
import { TestConditionResult, ParameterSweepResult, PillarLayoutSweepResult } from '../types';
import { Card } from './common/Card';
import { ChartIcon } from './common/Icons';

interface PerformanceChartsProps {
  data: TestConditionResult[];
  sweepData: ParameterSweepResult[];
  pillarLayoutSweepData: PillarLayoutSweepResult[];
}

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/80 backdrop-blur-sm border border-gray-300 p-3 rounded-md shadow-lg text-sm">
        <p className="label font-bold text-gray-800 mb-2">{`Flow Rate : ${label} mL/hr`}</p>
        {payload.map((pld: any) => (
          <div key={pld.dataKey} style={{ color: pld.stroke }} className="flex justify-between items-center">
            <span className='text-gray-700'>{`Hct ${pld.payload.hematocrit.toFixed(2)}:`}</span>
            <span className='font-bold ml-4'>{`${pld.value.toFixed(4)}`}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const CustomScatterTooltip: React.FC<any> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white/80 backdrop-blur-sm border border-gray-300 p-3 rounded-md shadow-lg text-sm">
        <p className="font-bold text-gray-800 mb-2">Purity: <span className="font-mono">{data.plasma_purity.toFixed(4)}</span></p>
        <p className="text-gray-700">Diameter: <span className="font-mono">{data.pillar_diameter.toFixed(2)} µm</span></p>
        <p className="text-gray-700">Spacing: <span className="font-mono">{data.pillar_spacing_x.toFixed(2)} µm</span></p>
      </div>
    );
  }
  return null;
};


const PerformanceChart: React.FC<{
  data: TestConditionResult[];
  xKey: string;
  yKey: string;
  title: string;
  xLabel: string;
  yLabel: string;
}> = ({ data, xKey, yKey, title, xLabel, yLabel }) => {

    const hematocritLevels = [...new Set(data.map(item => item.hematocrit))].sort();
    const colors = ['#0ea5e9', '#ec4899', '#f59e0b', '#818cf8', '#22c55e'];

    return (
        <Card title={title}>
            <div style={{ width: '100%', height: 300 }}>
                 <ResponsiveContainer>
                    <AreaChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 25 }}>
                         <defs>
                            {hematocritLevels.map((hct, index) => (
                                <linearGradient key={`color-${index}`} id={`color-${yKey}-${index}`} x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={colors[index % colors.length]} stopOpacity={0.8}/>
                                    <stop offset="95%" stopColor={colors[index % colors.length]} stopOpacity={0}/>
                                </linearGradient>
                            ))}
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey={xKey} stroke="#6b7280" dy={10} label={{ value: xLabel, position: 'insideBottom', offset: -15, fill: '#6b7280'}} />
                        <YAxis stroke="#6b7280" domain={['dataMin - 0.01', 'auto']} tickFormatter={(tick) => typeof tick === 'number' ? tick.toFixed(3) : tick} label={{ value: yLabel, angle: -90, position: 'insideLeft', offset: -5, fill: '#6b7280' }}/>
                        <Tooltip content={<CustomTooltip />} />
                        <Legend wrapperStyle={{paddingTop: 25}} />
                        {hematocritLevels.map((hct, index) => (
                             <Area 
                                key={hct}
                                type="monotone" 
                                data={data.filter(d => d.hematocrit === hct)}
                                dataKey={yKey} 
                                name={`Hct ${hct.toFixed(2)}`}
                                stroke={colors[index % colors.length]} 
                                strokeWidth={2}
                                fillOpacity={1} 
                                fill={`url(#color-${yKey}-${index})`}
                                activeDot={{ r: 6 }}
                            />
                        ))}
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </Card>
    )
}

const PurityScatterPlot: React.FC<{ data: ParameterSweepResult[] }> = ({ data }) => {
  if (!data || data.length === 0) return null;

  const purityDomain = [Math.min(...data.map(p => p.plasma_purity)), Math.max(...data.map(p => p.plasma_purity))];
  const colorScale = (purity: number) => {
    const t = (purity - purityDomain[0]) / (purityDomain[1] - purityDomain[0]);
    let r, g, b;
    if (t < 0.5) {
      // Blue to Green
      const local_t = t * 2;
      r = 0;
      g = Math.round(255 * local_t);
      b = Math.round(255 * (1 - local_t));
    } else {
      // Green to Yellow
      const local_t = (t - 0.5) * 2;
      r = Math.round(255 * local_t);
      g = 255;
      b = 0;
    }
    return `rgb(${r},${g},${b})`;
  };

  return (
    <Card title="Purity vs. Pillar Geometry">
      <div className='text-xs text-gray-500 -mt-2 mb-2'>Color indicates purity: <span className='font-bold' style={{color: 'rgb(0,0,255)'}}>Blue (Low)</span> to <span className='font-bold' style={{color: 'rgb(255,255,0)'}}>Yellow (High)</span></div>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
          <ScatterChart margin={{ top: 5, right: 30, left: 20, bottom: 25 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis
              type="number"
              dataKey="pillar_diameter"
              name="Pillar Diameter"
              unit="µm"
              stroke="#6b7280" dy={10}
              domain={['dataMin', 'dataMax']}
              tickFormatter={(tick) => tick.toFixed(0)}
              label={{ value: 'Pillar Diameter (µm)', position: 'insideBottom', offset: -15, fill: '#6b7280'}}
            />
            <YAxis
              type="number"
              dataKey="pillar_spacing_x"
              name="Pillar Spacing"
              unit="µm"
              stroke="#6b7280"
              tickFormatter={(tick) => tick.toFixed(0)}
              label={{ value: 'Pillar Spacing (µm)', angle: -90, position: 'insideLeft', offset: -5, fill: '#6b7280' }}
            />
            <Tooltip cursor={{ strokeDasharray: '3 3' }} content={<CustomScatterTooltip />} />
            <Scatter data={data} fill="#8884d8">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colorScale(entry.plasma_purity)} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};

const PillarLayoutHeatmap: React.FC<{ data: PillarLayoutSweepResult[], zKey: 'plasma_purity' | 'plasma_recovery', title: string }> = ({ data, zKey, title }) => {
  if (!data || data.length === 0) return null;

  const zDomain = [Math.min(...data.map(p => p[zKey])), Math.max(...data.map(p => p[zKey]))];
  const colorScale = (value: number) => {
    const t = (value - zDomain[0]) / (zDomain[1] - zDomain[0] || 1);
    const hue = 240 - t * 180; // Blue (240) -> Green (120) -> Yellow (60)
    return `hsl(${hue}, 90%, 50%)`;
  };

  const xDomain = [Math.min(...data.map(p => p.num_pillar_cols)), Math.max(...data.map(p => p.num_pillar_cols))];
  const yDomain = [Math.min(...data.map(p => p.num_pillar_rows)), Math.max(...data.map(p => p.num_pillar_rows))];
  
  return (
    <Card title={title}>
      <div className='text-xs text-gray-500 -mt-2 mb-2'>Color indicates performance: <span className='font-bold' style={{color: 'hsl(240, 90%, 50%)'}}>Blue (Low)</span> to <span className='font-bold' style={{color: 'hsl(60, 90%, 50%)'}}>Yellow (High)</span></div>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
          <ScatterChart margin={{ top: 5, right: 30, left: 20, bottom: 25 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis
              type="number" dataKey="num_pillar_cols" name="Columns"
              stroke="#6b7280" dy={10} domain={xDomain} allowDecimals={false}
              label={{ value: 'Pillar Columns', position: 'insideBottom', offset: -15, fill: '#6b7280'}}
            />
            <YAxis
              type="number" dataKey="num_pillar_rows" name="Rows"
              stroke="#6b7280" domain={yDomain} allowDecimals={false}
              label={{ value: 'Pillar Rows', angle: -90, position: 'insideLeft', offset: -5, fill: '#6b7280' }}
            />
            <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const tooltipData = payload[0].payload;
                return (
                  <div className="bg-white/80 backdrop-blur-sm border border-gray-300 p-3 rounded-md shadow-lg text-sm">
                    <p className="font-bold text-gray-800 mb-2">{zKey.includes('purity') ? 'Purity' : 'Recovery'}: <span className="font-mono">{tooltipData[zKey].toFixed(4)}</span></p>
                    <p className="text-gray-700">Rows: <span className="font-mono">{tooltipData.num_pillar_rows}</span>, Cols: <span className="font-mono">{tooltipData.num_pillar_cols}</span></p>
                  </div>
                );
              }
              return null;
            }}/>
            {/* FIX: Use ZAxis to control the size of the scatter points and remove invalid `nodeSize` prop. */}
            <ZAxis type="number" dataKey="size" range={[200, 200]} />
            <Scatter data={data.map(d => ({ ...d, size: 1 }))} fill="#8884d8" shape="square" isAnimationActive={false}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colorScale(entry[zKey])} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};


export const PerformanceCharts: React.FC<PerformanceChartsProps> = ({ data, sweepData, pillarLayoutSweepData }) => {
  if ((!data || data.length === 0) && (!sweepData || sweepData.length === 0)) {
     return (
        <Card title="Performance Analysis" className="flex items-center justify-center h-full min-h-[360px]">
            <div className="text-center text-gray-500">
                <ChartIcon className="w-16 h-16 mx-auto mb-4 text-gray-400"/>
                <p>Performance analysis charts will appear here after optimization.</p>
            </div>
        </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
       <PerformanceChart data={data} xKey="flow_rate" yKey="plasma_purity" title="Plasma Purity vs. Flow Rate" xLabel="Inlet Flow Rate (mL/hr)" yLabel="Plasma Purity" />
       <PerformanceChart data={data} xKey="flow_rate" yKey="plasma_recovery" title="Plasma Recovery vs. Flow Rate" xLabel="Inlet Flow Rate (mL/hr)" yLabel="Plasma Recovery"/>
       <PurityScatterPlot data={sweepData} />
       <PerformanceChart data={data} xKey="flow_rate" yKey="pressure_drop_kPa" title="Pressure Drop vs. Flow Rate" xLabel="Inlet Flow Rate (mL/hr)" yLabel="Pressure Drop (kPa)" />
       {pillarLayoutSweepData && pillarLayoutSweepData.length > 0 && (
         <>
            <PillarLayoutHeatmap data={pillarLayoutSweepData} zKey="plasma_purity" title="Purity vs. Pillar Layout" />
            <PillarLayoutHeatmap data={pillarLayoutSweepData} zKey="plasma_recovery" title="Recovery vs. Pillar Layout" />
         </>
       )}
    </div>
  );
};