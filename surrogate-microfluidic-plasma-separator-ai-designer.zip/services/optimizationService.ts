
import { DesignParameters, PerformanceMetrics, TestConditionResult, ParameterSweepResult, PillarLayoutSweepResult } from '../types';

export const designParameterBounds = {
  channel_width: { min: 50, max: 200, unit: 'µm' },
  channel_height: { min: 20, max: 80, unit: 'µm' },
  pillar_diameter: { min: 10, max: 50, unit: 'µm' },
  pillar_spacing_x: { min: 20, max: 100, unit: 'µm' },
  pillar_spacing_y: { min: 20, max: 100, unit: 'µm' },
  num_pillar_rows: { min: 3, max: 15, unit: '' },
  num_pillar_cols: { min: 3, max: 15, unit: '' },
  inlet_flow_rate: { min: 0.5, max: 5.0, unit: 'mL/hr' },
  blood_hematocrit: { min: 0.35, max: 0.45, unit: '' },
};

// This function simulates the trained DL surrogate model from the notebook.
// It uses similar non-linear relationships and noise to mimic its predictive behavior.
export const mockSurrogateModel = (params: DesignParameters, complexityFactor = 1.0): PerformanceMetrics => {
  // Plasma Purity calculations
  const base_purity = 0.75;
  const purity_from_pillars = Math.exp(-((params.pillar_diameter - 30) ** 2) / (2 * 10 ** 2)) * 0.15;
  const purity_from_spacing = 0.1 * (1 - Math.abs(params.pillar_spacing_x - 60) / 60);
  const purity_from_flow = -0.05 * (params.inlet_flow_rate / 5.0);
  const purity_from_hematocrit = 0.1 * (0.40 - params.blood_hematocrit);
  let plasma_purity = base_purity + purity_from_pillars + purity_from_spacing + purity_from_flow + purity_from_hematocrit;
  plasma_purity = Math.max(0.6, Math.min(0.99, plasma_purity + (Math.random() - 0.5) * 0.04 * complexityFactor));

  // Plasma Recovery calculations
  const base_recovery = 0.60;
  const recovery_from_width = 0.1 * (params.channel_width / 200);
  const recovery_from_spacing = 0.05 * (params.pillar_spacing_x / 100);
  const recovery_from_flow = 0.1 * (params.inlet_flow_rate / 5.0);
  const recovery_from_hematocrit = -0.05 * (params.blood_hematocrit - 0.40);
  let plasma_recovery = base_recovery + recovery_from_width + recovery_from_spacing + recovery_from_flow + recovery_from_hematocrit;
  plasma_recovery = Math.max(0.5, Math.min(0.95, plasma_recovery + (Math.random() - 0.5) * 0.06 * complexityFactor));

  // Pressure Drop calculations
  let pressure_drop = (params.inlet_flow_rate / 0.5) ** 1.5 * (1 / params.channel_width) * (1 / params.pillar_spacing_x) * (params.num_pillar_rows * params.num_pillar_cols) * 0.01;
  pressure_drop = Math.max(0.1, Math.min(10.0, pressure_drop + (Math.random() - 0.5) * 0.2 * complexityFactor));

  return { plasma_purity, plasma_recovery, pressure_drop_kPa: pressure_drop };
};


export async function runOptimization(
  iterations: number,
  onProgress: (progress: number, bestFitness: number) => void
): Promise<{ bestDesignParams: DesignParameters, predictedPerformance: PerformanceMetrics }> {
  let bestFitness = -Infinity;
  let bestDesignParams: DesignParameters | null = null;
  let predictedPerformance: PerformanceMetrics | null = null;

  for (let i = 0; i < iterations; i++) {
    const candidate_params: DesignParameters = {
      channel_width: Math.random() * (200 - 50) + 50,
      channel_height: Math.random() * (80 - 20) + 20,
      pillar_diameter: Math.random() * (50 - 10) + 10,
      pillar_spacing_x: Math.random() * (100 - 20) + 20,
      pillar_spacing_y: Math.random() * (100 - 20) + 20,
      num_pillar_rows: Math.floor(Math.random() * (15 - 3) + 3),
      num_pillar_cols: Math.floor(Math.random() * (15 - 3) + 3),
      inlet_flow_rate: Math.random() * (5.0 - 0.5) + 0.5,
      blood_hematocrit: Math.random() * (0.45 - 0.35) + 0.35,
    };

    const performance = mockSurrogateModel(candidate_params);
    
    // Objective/Fitness function: Maximize purity and recovery, minimize pressure drop
    const fitness = performance.plasma_purity * 0.5 + performance.plasma_recovery * 0.3 - (performance.pressure_drop_kPa / 10) * 0.2;

    if (fitness > bestFitness) {
      bestFitness = fitness;
      bestDesignParams = candidate_params;
      predictedPerformance = performance;
    }

    if (i % Math.floor(iterations / 100) === 0 || i === iterations - 1) {
      const progress = (i + 1) / iterations;
      onProgress(progress, bestFitness);
      await new Promise(resolve => setTimeout(resolve, 10)); // Allow UI to update
    }
  }

  if (!bestDesignParams || !predictedPerformance) {
    throw new Error("Optimization failed to find a valid design.");
  }
  
  return { bestDesignParams, predictedPerformance };
}


export const testUnderVaryingConditions = (designParams: DesignParameters): TestConditionResult[] => {
  const testFlowRates = [1.0, 1.8, 2.5, 3.2, 4.0];
  const testHematocrits = [0.30, 0.35, 0.40, 0.45, 0.50];
  const results: TestConditionResult[] = [];

  for (const flow_rate of testFlowRates) {
    for (const hematocrit of testHematocrits) {
      const testParams = { ...designParams, inlet_flow_rate: flow_rate, blood_hematocrit: hematocrit };
      // Using a higher complexity factor to simulate a more detailed "final" simulation
      const performance = mockSurrogateModel(testParams, 2.0);
      results.push({ ...performance, flow_rate, hematocrit });
    }
  }
  return results;
};

export const generateParameterSweepData = (baseParams: DesignParameters): ParameterSweepResult[] => {
  const results: ParameterSweepResult[] = [];
  const num_steps = 20; // 20x20 grid for 400 data points
  const diameter_range = designParameterBounds.pillar_diameter;
  const spacing_range = designParameterBounds.pillar_spacing_x;

  for (let i = 0; i < num_steps; i++) {
    for (let j = 0; j < num_steps; j++) {
      const pillar_diameter = diameter_range.min + (i / (num_steps - 1)) * (diameter_range.max - diameter_range.min);
      const pillar_spacing_x = spacing_range.min + (j / (num_steps - 1)) * (spacing_range.max - spacing_range.min);

      const testParams = {
        ...baseParams,
        pillar_diameter,
        pillar_spacing_x,
      };

      const performance = mockSurrogateModel(testParams);
      results.push({
        pillar_diameter,
        pillar_spacing_x,
        plasma_purity: performance.plasma_purity,
      });
    }
  }
  return results;
};

export const generatePillarLayoutSweepData = (baseParams: DesignParameters): PillarLayoutSweepResult[] => {
  const results: PillarLayoutSweepResult[] = [];
  const rows_range = designParameterBounds.num_pillar_rows;
  const cols_range = designParameterBounds.num_pillar_cols;

  for (let rows = rows_range.min; rows <= rows_range.max; rows++) {
    for (let cols = cols_range.min; cols <= cols_range.max; cols++) {
      const testParams = {
        ...baseParams,
        num_pillar_rows: rows,
        num_pillar_cols: cols,
      };

      const performance = mockSurrogateModel(testParams);
      results.push({
        num_pillar_rows: rows,
        num_pillar_cols: cols,
        plasma_purity: performance.plasma_purity,
        plasma_recovery: performance.plasma_recovery,
      });
    }
  }
  return results;
};