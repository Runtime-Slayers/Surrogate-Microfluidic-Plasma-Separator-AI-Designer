
import { GoogleGenAI } from "@google/genai";
import { DesignParameters, PerformanceMetrics } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export async function generateDesignRationale(
  params: DesignParameters,
  performance: PerformanceMetrics
): Promise<string> {
  if (!API_KEY) {
    return Promise.resolve("Error: API_KEY is not configured. Cannot generate AI analysis.");
  }

  const prompt = `
You are an expert in microfluidics and biomedical engineering. Given the following optimized design parameters and performance metrics for a microfluidic plasma separator, provide a concise and insightful analysis.

**Optimized Design Parameters:**
- Channel Width: ${params.channel_width.toFixed(2)} µm
- Channel Height: ${params.channel_height.toFixed(2)} µm
- Pillar Diameter: ${params.pillar_diameter.toFixed(2)} µm
- Pillar Spacing (X): ${params.pillar_spacing_x.toFixed(2)} µm
- Pillar Spacing (Y): ${params.pillar_spacing_y.toFixed(2)} µm
- Pillar Rows: ${params.num_pillar_rows}
- Pillar Columns: ${params.num_pillar_cols}
- Inlet Flow Rate: ${params.inlet_flow_rate.toFixed(2)} mL/hr
- Blood Hematocrit: ${(params.blood_hematocrit * 100).toFixed(1)}%

**Predicted Performance:**
- Plasma Purity: ${performance.plasma_purity.toFixed(4)}
- Plasma Recovery: ${performance.plasma_recovery.toFixed(4)}
- Pressure Drop: ${performance.pressure_drop_kPa.toFixed(4)} kPa

Your analysis should be structured in three sections:

1.  **Design Rationale:** Explain the likely reasons why this combination of parameters is optimal based on fluid dynamics principles. Discuss the interplay between pillar size, spacing, and channel dimensions on separation efficiency and flow dynamics.
2.  **Performance Interpretation:** Comment on the performance metrics. Is the purity high? Is the recovery rate good? Is the pressure drop acceptable for typical microfluidic systems?
3.  **Manufacturing & Next Steps:** Suggest potential microfabrication techniques (e.g., PDMS soft lithography, deep reactive-ion etching) suitable for this design. Recommend the crucial next steps for validating this in-silico design.

Format your response using markdown for clarity (e.g., headings, bold text, lists).
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "An error occurred while generating the AI analysis. Please check the console for details.";
  }
}
