import { DesignParameters } from '../types';

// Constants for blood properties (simplified)
const BLOOD_DENSITY = 1060; // kg/m^3
const BLOOD_VISCOSITY = 0.0035; // Pa·s (at high shear, can vary)
const CELL_DIAMETER = 8e-6; // meters (for RBC)
const DIFFUSIVITY = 1e-11; // m^2/s (approx. for small molecules in plasma)

/**
 * Calculates key fluid dynamics metrics for the given microfluidic channel design.
 * All units are converted to SI for calculations.
 */
export const calculatePhysicsMetrics = (params: DesignParameters) => {
  // Convert all dimensions from µm to meters
  const width_m = params.channel_width * 1e-6;
  const height_m = params.channel_height * 1e-6;
  
  // Convert flow rate from mL/hr to m^3/s
  const flow_rate_m3_s = params.inlet_flow_rate * (1e-6 / 3600);
  
  // Calculate cross-sectional area (m^2)
  const area = width_m * height_m;
  
  // 1. Average Velocity (U = Q / A)
  const averageVelocity = flow_rate_m3_s / area;
  
  // 2. Hydraulic Diameter (Dh = 4A / P)
  const perimeter = 2 * (width_m + height_m);
  const hydraulicDiameter = (4 * area) / perimeter;
  
  // 3. Reynolds Number (Re = ρUDh / μ) - indicates flow regime (laminar vs turbulent)
  const reynoldsNumber = (BLOOD_DENSITY * averageVelocity * hydraulicDiameter) / BLOOD_VISCOSITY;
  
  // 4. Péclet Number (Pe = LU / D) - convection vs diffusion dominance
  // Using channel width as the characteristic length L
  const pecletNumber = (width_m * averageVelocity) / DIFFUSIVITY;
  
  // 5. Maximum Wall Shear Stress (τ = 6μQ / wh^2) - for rectangular channel
  const maxWallShearStress = (6 * BLOOD_VISCOSITY * flow_rate_m3_s) / (width_m * height_m ** 2);

  return {
    averageVelocity,
    reynoldsNumber,
    pecletNumber,
    maxWallShearStress,
  };
};
